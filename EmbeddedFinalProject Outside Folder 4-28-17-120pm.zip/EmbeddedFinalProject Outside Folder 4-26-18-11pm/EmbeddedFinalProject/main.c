/*
 * EmbeddedFinalProject.c
 *
 * Created: 4/18/2018 8:07:23 PM
 * Author : Jacob / Josh
 */ 

#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#define bit_is_clear(sfr,bit) (!(_SFR_BYTE(sfr) & _BV(bit)))

#include "util/delay.h"
#include "nokia5110.h"
#define BAUD_RATE 9600        //Baud Rate
#define F_CPU 8000000L        //Clock Frequency
#define RX_BUFFER_SIZE 64

unsigned char rx_buffer[RX_BUFFER_SIZE];//variables and functions for rx buffer
volatile unsigned char rx_buffer_head;
volatile unsigned char rx_buffer_tail;

/*USART functions*/
char uart_buffer_empty(void);
void usart_init(void);
void usart_putData(const char data);
char usart_getData(void);

/*Motor functions*/
void pwmInit0(void);
void servoOpen0(void);
void pwmInit2(void);
void servoOpen2(void);


//fingerprint sensor functions
void fpsInit(char commandArray[]);
int CalculateChecksum(char commandArray[]);
void fpsFlash(char commandArray[]);


//LCD Functions
void printMenu();
void enrollUserPrint();
//*char removeUser();
void settingsMenuPrint();

//int debugArray[] = {0};
//void commandsStringDebug(int debugArray[], int command);	
	
	



int main(void)
{
	
	//********************* RPG MENU SCROLL***************************	
	//DDRB = 0b00000110	//PB1, PB2 inputs from the RPG
	//DDRD = 0b00000110;
	//PORTD = 0b00000110;	//enable pull up resistors 
	
	
	
		
	
	DDRD = 0b00010100;	// set PD2 as input (PD2 = INT1)
	PORTD |= 0b00000100;  // PD2 pull-up enabled  

	EIMSK |= (1<<INT0);		// enable INT1
	EICRA |= (1<<ISC00); //  rising edge
	sei();
	
	
	while(1)
	{
		//do nothing ;)
		_delay_ms(1);
	}
	
		
		
}
		
/*4-29-18 ACTION PLAN		
	1) get the mag strip reader working
	2) get the RPG ISR moving the arrow
	3) talk to someone at the shop or beichel/kruger about additional hardware for 2nd servo	
*/		



	//*****************************************************************
	
		/*
		// Motor Code
		DDRD = 0b00101000 ; // set PD3 and PD5 as an output for the servo
		pwmInit0();
		pwmInit2();
		servoOpen0();
	*/

	//********************           LCD          *************************************
	nokia_lcd_init();
	DDRB = 0b00111110;
	int arrowPosition = 10;	//start the arrow on the 2nd line of the LCD
	int menuChoice = 0, menuChoice2 = 0;
	 

	printMenu(arrowPosition);
	
	//user will change arrow location by ISR
	//enable function for user to select choice (arrow location) by pushing button

	//enroll user
	if(menuChoice = 10){	
		enrollUserPrint();
		//function to enroll user
	}
	
	
	
	//Remove User
	else if (menuChoice = 20){ 
		removeUserPrint();
		//function to remove user	
	}
	
	
	
	
	// Settings
	else if (menuChoice = 30){ 
		settingsMenuPrint();
		if (menuChoice2 = 10){	//set coffee
			//function to setCoffee
		}
		else if (menuChoice2 = 20){	//set creamer
			//function to setCreamer
		}
		else{	//empty lines -- invalid input
			nokia_lcd_clear();
			nokia_lcd_set_cursor(0,0);
			nokia_lcd_write_string("Please Enter", 1);
			nokia_lcd_set_cursor(0,0);
			nokia_lcd_write_string("Valid Input", 1);
			nokia_lcd_render();
		}
	}
	
	
	// Auto Pour
	else if (menuChoice = 40){
		autoPourPrint();
		//function to read user swipe
		
		//functions to operate servos and pour
	}
	else{	// i don't think this condition can ever be met with our system the arrow will always be 10,20,30,40
		nokia_lcd_clear();
		nokia_lcd_set_cursor(0,0);
		nokia_lcd_write_string("Please Enter", 1);
		nokia_lcd_set_cursor(0,0);
		nokia_lcd_write_string("Valid Input", 1);
		nokia_lcd_render();
	}
	
	
	
	
	
	
}//end main







//%%%%%%%%%%%%%%%%%&&&&%%%%%% FUNCTION DEFINITIONS &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

//********************       Servo PWM      *************************************
void pwmInit0(void){
	
	
	TCCR0A |= (1<<WGM01) | (1<<WGM00) | (1<<COM0B1);	// configuring for fast pwm
	
	TCCR0B |= (1<<WGM02) | (1<< CS02) | (1<< CS00);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR0A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR0B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
}

void servoOpen0(void) {
	
	OCR0B = 16;
}

void pwmInit2(void){
	
	
	TCCR2A |= (1<<WGM21) | (1<<WGM20) | (1<<COM2B1);	// configuring for fast pwm
	
	TCCR2B |= (1<<WGM22) | (1<< CS22) | (1<< CS21) | (1<< CS20);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR2A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR2B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
	
	
}

void servoOpen2(void) {
	
	OCR2B = 16;
}



//************************     USART HAPPY FUN TIME     *************************

/*Interrupt service routine for buffer*/
ISR(USART_RX_vect)
{
	// UART receive interrupt handler.
	// To do: check and warn if buffer overflows.
	
	char c = UDR0;
	rx_buffer[rx_buffer_head] = c;
	if (rx_buffer_head == RX_BUFFER_SIZE - 1)
	rx_buffer_head = 0;
	else
	rx_buffer_head++;
}

/*USART Initialization*/
void usart_init(void)
{	unsigned short s;//variable for Baud Rate

	s = (double)F_CPU / (BAUD_RATE*16.0) - 1.0;//Baud Rate Calculation
	UBRR0H = (s & 0xFF00);//set high byte
	UBRR0L = (s & 0x00FF);//set low byte

	UCSR0B = (1<<RXCIE0)|(1<<RXEN0)|(1<<TXEN0);//enable hardware interrupt on rx, enable tx,rx

	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);//8N1 communication
	
	DDRD |= (1<< 1);         // PD0 is output (TX)
	DDRD &= ~(1<< 0);        // PD1 is input (Rx)
	
	rx_buffer_head = 0; //empty buffer
	rx_buffer_tail = 0;
}

/*return typed char to USART*/
void usart_putData(const char data){
	// Send "c" via the USART.  Uses poling
	// (and it blocks). Wait for UDRE0 to become
	// set (=1), which indicates the UDR0 is empty
	// and can accept the next character.

	while (!(UCSR0A & (1<<UDRE0)))
	;
	UDR0 = data;
}

/*Get character from receive buffer*/
char usart_getData(void)
{	// Get char from the receiver buffer.  This
	// function blocks until a character arrives.
	
	unsigned char  data;
	
	// Wait for a character in the buffer.

	while (rx_buffer_tail == rx_buffer_head)
	;
	
	data = rx_buffer[rx_buffer_tail];
	if (rx_buffer_tail == RX_BUFFER_SIZE-1)
	rx_buffer_tail = 0;
	else
	rx_buffer_tail++;
	return data;
}

/*Character Buffer*/
 char uart_buffer_empty(void)
{
	// Returns TRUE if receive buffer is empty.
	return (rx_buffer_tail == rx_buffer_head);
}


//*************************************LCD FUNCTIONS********************************************
void printMenu(int arrowPosition){
		cli();	//we dont want another turn of the rpg to trigger a nested ISR inside of this
		//initial screen print
		nokia_lcd_clear();
		nokia_lcd_set_cursor(0 , 0);
		nokia_lcd_write_string( "  MAIN MENU",1);
		nokia_lcd_set_cursor(0 , arrowPosition);
		nokia_lcd_write_string( "->",1);
		nokia_lcd_set_cursor(15, 10);
		nokia_lcd_write_string( "Enroll User",1);
		nokia_lcd_set_cursor(15, 20);
		nokia_lcd_write_string("Remove User", 1);
		nokia_lcd_set_cursor(15, 30);
		nokia_lcd_write_string( "Settings",1);
		nokia_lcd_set_cursor(15, 40);
		nokia_lcd_write_string( "Auto Pour",1);
		nokia_lcd_render();
		
}


//this function should be our interrupt service routine!! (you cant call functions from ISRS
//so we will just copy this code into the ISR)
/*
int moveArrow(int arrowPosition){
	
	//need to put code here to use the proper ISR vectors
	//we will need to use 2 pin change interrupts in our case
	
		cli();	//we don't want another turn of the RPG to trigger a nested ISR inside of this

		if (){ //CW rotation (arrow down)
			if(arrowPosition < 40){
				arrowPosition = (arrowPosition + 10);	//moves arrow down 1 line
			}
			else{	//arrow is at bottom line of LCD, must take back to top
				arrowPosition = 10;
			}
		} 
		
		
		else if (){ //CCW rotation (arrow up)
			if(arrowPosition > 10){
				arrowPosition = (arrowPosition - 10);	//move the arrow up 1 line
			}
			else{	//arrow is as top line of LCD, must take back to bottom
				arrowPosition = 40;
			}
		}
		
		
		else{ //no rotation
		}
		
		return arrowPosition;	//sends back the updated arrow position for printing purposes	
}*/



void enrollUserPrint(){
	nokia_lcd_clear();
	nokia_lcd_set_cursor(0,0);
	nokia_lcd_write_string( " ENROLL USER",1);
	nokia_lcd_set_cursor(0,10);
	nokia_lcd_write_string( "Please Swipe",1);
	nokia_lcd_set_cursor(0,20);
	nokia_lcd_write_string("Card...",1);
	nokia_lcd_render();
}


void removeUserPrint(){
	nokia_lcd_clear();
	nokia_lcd_set_cursor(0,0);
	nokia_lcd_write_string( " REMOVE USER",1);
	nokia_lcd_set_cursor(0,10);
	nokia_lcd_write_string( "Please Swipe",1);
	nokia_lcd_set_cursor(0,20);
	nokia_lcd_write_string("Card...",1);
	nokia_lcd_render();
}


void settingsMenuPrint(){
	
	//before we can do this we need to have the user identify themselves too
		nokia_lcd_clear();
		nokia_lcd_set_cursor(0 , 0);
		nokia_lcd_write_string( "   SETTINGS",1);
		nokia_lcd_set_cursor(0 , 10);
		nokia_lcd_write_string( "->",1);
		nokia_lcd_set_cursor(15,10);
		nokia_lcd_write_string( "Set Coffee",1);
		nokia_lcd_set_cursor(15,20);
		nokia_lcd_write_string( "Set Creamer",1);
		nokia_lcd_render();
}


void autoPourPrint(){
	nokia_lcd_clear();
	nokia_lcd_set_cursor(0,0);
	nokia_lcd_write_string( "  AUTO POUR",1);
	nokia_lcd_set_cursor(0,10);
	nokia_lcd_write_string( "Swipe Card",1);
	nokia_lcd_set_cursor(0,20);
	nokia_lcd_write_string( "to Dispense...",1);
	nokia_lcd_render();
	//maybe call a fxn here to alert the strip reader to wait for a swipe?
}





//******************************RPG FUNCTIONS************************************

/*
uint8_t read_gray_code_from_encoder(void )
{
	uint8_t val=0;

	if(!bit_is_clear(PIND, PD2))
	val |= (1<<1);

	if(!bit_is_clear(PIND, PD3))
	val |= (1<<0);

	return val;
}
*/

//RPG INT0 interrupt
ISR(INT0_vect )
{
	cli();
	if(!bit_is_clear(PIND, PD2))
	{
		PORTD |=0b00010000;
	}
	else
	{
		PORTD |=0b00000000;
	}
}

