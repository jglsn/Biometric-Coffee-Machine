/*
 * EmbeddedFinalProject.c
 *
 * Created: 4/18/2018 8:07:23 PM
 * Author : Jacob / Josh
 */ 

#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include "util/delay.h"
#include "nokia5110.h"
#define BAUD_RATE 9600        //Baud Rate
#define F_CPU 8000000L        //Clock Frequency
#define RX_BUFFER_SIZE 64

unsigned char rx_buffer[RX_BUFFER_SIZE];//variables and functions for rx buffer
volatile unsigned char rx_buffer_head;
volatile unsigned char rx_buffer_tail;

/*USART functions*/
char uart_buffer_empty(void);
void usart_init(void);
void usart_putData(const char data);
char usart_getData(void);

/*Motor functions*/
void pwmInit0(void);
void servoOpen0(void);
void pwmInit2(void);
void servoOpen2(void);


//fingerprint sensor functions
void fpsInit(char commandArray[]);
int CalculateChecksum(char commandArray[]);
void fpsFlash(char commandArray[]);


//LCD Functions
void printMenu();


//int debugArray[] = {0};
//void commandsStringDebug(int debugArray[], int command);	
	
	



int main(void)
{
	
//********************* RPG MENU SCROLL***************************	
//	DDRB = 0b00000110	//PB1, PB2 inputs from the RPG
	
	
	//DDRD = 0b00000010;
	//PORTD = 0b00000010;	//enable pull up resistors 
//*****************************************************************
	
    char open[12]={0x55,0xAA, 0x01, 0x00,0x00,0x00,0x00,0x00,0x01, 0x00, 0x01, 0x01};			//arrays of commands that we send to the FPS over USART
	char ledFlash[10]={0x55,0xAA, 0x01, 0x00, 0x01, 0x00, 0x00, 0x00, 0x12, 0x00};
	sei();//enable global interrupts
	//fpsInit(open);	
	//_delay_ms(1000);
	
//	while(1){
	//ledFlash[4]=0x01;//turn on led
	//fpsFlash(ledFlash);
	//_delay_ms(1000);
	//ledFlash[4]=0x00;//turn off led
	//fpsFlash(ledFlash);
	//_delay_ms(1000);
	//}
	

	
	
	/*
	// Motor Code
	DDRD = 0b00101000 ; // set PD3 as an output for the servo
	pwmInit0();
	pwmInit2();
	servoOpen0();
*/

//********************           LCD          *************************************
	DDRB = 0b00111110;
	//char menu[3] = {"Add User", "Remove User", "Set Coffee", "Set Creamer"};
	
	
	
printMenu();
	
}//end main

//********************       Servo PWM      *************************************
void pwmInit0(void){
	
	
	TCCR0A |= (1<<WGM01) | (1<<WGM00) | (1<<COM0B1);	// configuring for fast pwm
	
	TCCR0B |= (1<<WGM02) | (1<< CS02) | (1<< CS00);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR0A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR0B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
	
	
}

void servoOpen0(void) {
	
	OCR0B = 16;
}

void pwmInit2(void){
	
	
	TCCR2A |= (1<<WGM21) | (1<<WGM20) | (1<<COM2B1);	// configuring for fast pwm
	
	TCCR2B |= (1<<WGM22) | (1<< CS22) | (1<< CS21) | (1<< CS20);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR2A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR2B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
	
	
}

void servoOpen2(void) {
	
	OCR2B = 16;
}



//************************     USART HAPPY FUN TIME     *************************

/*Interrupt service routine for buffer*/
ISR(USART_RX_vect)
{
	// UART receive interrupt handler.
	// To do: check and warn if buffer overflows.
	
	char c = UDR0;
	rx_buffer[rx_buffer_head] = c;
	if (rx_buffer_head == RX_BUFFER_SIZE - 1)
	rx_buffer_head = 0;
	else
	rx_buffer_head++;
}

/*Usart Initialization*/
void usart_init(void)
{	unsigned short s;//variable for Baud Rate

	s = (double)F_CPU / (BAUD_RATE*16.0) - 1.0;//Baud Rate Calculation
	UBRR0H = (s & 0xFF00);//set high byte
	UBRR0L = (s & 0x00FF);//set low byte

	UCSR0B = (1<<RXCIE0)|(1<<RXEN0)|(1<<TXEN0);//enable hardware interrupt on rx, enable tx,rx

	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);//8N1 communication
	
	DDRD |= (1<< 1);         // PD0 is output (TX)
	DDRD &= ~(1<< 0);        // PD1 is input (Rx)
	
	rx_buffer_head = 0; //empty buffer
	rx_buffer_tail = 0;
}




/*return typed char to USART*/
void usart_putData(const char data){
	// Send "c" via the USART.  Uses poling
	// (and it blocks). Wait for UDRE0 to become
	// set (=1), which indicates the UDR0 is empty
	// and can accept the next character.

	while (!(UCSR0A & (1<<UDRE0)))
	;
	UDR0 = data;
}

/*Get character from receive buffer*/
char usart_getData(void)
{	// Get char from the receiver buffer.  This
	// function blocks until a character arrives.
	
	unsigned char  data;
	
	// Wait for a character in the buffer.

	while (rx_buffer_tail == rx_buffer_head)
	;
	
	data = rx_buffer[rx_buffer_tail];
	if (rx_buffer_tail == RX_BUFFER_SIZE-1)
	rx_buffer_tail = 0;
	else
	rx_buffer_tail++;
	return data;
}

/*Character Buffer*/
 char uart_buffer_empty(void)
{
	// Returns TRUE if receive buffer is empty.
	return (rx_buffer_tail == rx_buffer_head);
}


void fpsInit(char commandArray[]){
	usart_init();//initialize usart
	
	
	/*
	//open communication channel
	usart_putData(0x55);//start1
	usart_putData(0xAA);//start2
	usart_putData(0x01);//ID1
	usart_putData(0x00);//ID2
	
	usart_putData(0x00);//dword parameter
	usart_putData(0x00);
	usart_putData(0x00);
	usart_putData(0x00);
	
	usart_putData(0x01);//open low byte
	usart_putData(0x00);//open high byt
	
	usart_putData(0x01);//checkSum low
	usart_putData(0x01);//checkSum High
	
	usart_putData(0x03);//checkSum High
	usart_putData(0x01);//checkSum High
	
	*/
	
	for(int i=0; i<12; i++){
		usart_putData(commandArray[i]);	
	}
	
/*
	char sumHigh=0;										//add the last 2 values on to the 12 value long command packet that we send to the FPS
	char sumLow=0;
	int tempCheck=CalculateChecksum(commandArray);
	sumHigh=tempCheck & 0xFF00;						//must send the low byte of the checksum then the high byte
	sumLow=tempCheck & 0x00FF;
	usart_putData(sumLow);
		_delay_ms(2);
	usart_putData(sumHigh);
	
	*/
}

//function that takes the first 10 entries of the command array and sums them
int CalculateChecksum(char commandArray[])
{
	int w = 0;
	for(int j=0; j<10; j++){
		w=+commandArray[j];
	}

	return w;
}


void fpsFlash(char commandArray[]){
	for(int i=0; i<10; i++){						//sends 1st 10 commands over USART to FPS
		usart_putData(commandArray[i]);
				_delay_ms(2);
	}
	char sumHigh=0;
	char sumLow=0;
	int tempCheck=CalculateChecksum(commandArray);	//calculate last 2 commands
	sumHigh=tempCheck & 0xFF00;					
	sumLow=tempCheck & 0x00FF;
	usart_putData(sumLow);						//sends last 2 commands over USART to FPS
	_delay_ms(2);
	usart_putData(sumHigh);
}


/*
uint8_t read_gray_code_from_encoder(void )
{
	uint8_t val=0;

	if(!bit_is_clear(PIND, PD2))
	val |= (1<<1);

	if(!bit_is_clear(PIND, PD3))
	val |= (1<<0);

	return val;
}
*/

/*
//trying to make a function that will put out USART commands into an array of ints for debugging purposes
int array[] commandsStringDebug(int debugArray[], int command){
	
	for(int i =0, i<12, i++){
		debugArray[i] = command;
	
	}

}
*/



/*
void printWelcome(){
	
	nokia_lcd_clear();
	nokia_lcd_write_string("Welcome \n Please Log In",1);
}
*/
void printMenu(){
		nokia_lcd_init();
		nokia_lcd_clear();
		nokia_lcd_set_cursor(0 , 0);
		nokia_lcd_write_string( "->",1);
		nokia_lcd_set_cursor(15, 0);
		nokia_lcd_write_string( "Enroll User",1);
		nokia_lcd_set_cursor(15, 10);
		nokia_lcd_write_string("Remove User", 1);
		nokia_lcd_set_cursor(15, 20);
		nokia_lcd_write_string( "Settings",1);
		nokia_lcd_set_cursor(15, 30);
		nokia_lcd_write_string( "Auto Pour",1);
		nokia_lcd_render();
	
}


//https://exploreembedded.com/wiki/Interactive_Menus_for_your_project_with_a_Display_and_an_Encoder