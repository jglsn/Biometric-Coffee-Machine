/*
 * EmbeddedFinalProject.c
 *
 * Created: 4/18/2018 8:07:23 PM
 * Author : Jacob / Josh
 */ 

#include <avr/io.h>
#include "util/delay.h"
#include "nokia5110.h"



int main(void)
{
   
   
   //initialize motor pin 
   DDRD = 0b00001000 ; 
   
   pwmInit();
   
   _delay_ms(5000);
   servoOpen();
   
   
    while (1) 
    {
		
/*		
	*******************          LCD       ********************************	
	//to find the specifics on how they functions work see nokia5110.c	
	//must be called once to initialize the display
	nokia_lcd_init();
	//clear the screen
	nokia_lcd_clear();
	//the second param is the scale or size of the message
	nokia_lcd_write_string( "Its Working!",1);
	//X-horizontal position, Y - vertical position
	nokia_lcd_set_cursor(0, 10);
    nokia_lcd_write_string("Nice!", 3);
	//actually sends the written strings to the display
	nokia_lcd_render();
	 
	 for (;;) {
		 _delay_ms(1000);
	 } 
	 
*/

    }//end while
}//end main

//********************       Servo PWM      *************************************

void pwmInit(void){
	
	
	TCCR2A |= (1<<WGM21) | (1<<WGM20) | (1<<COM2B1);	// configuring for fast pwm
	
	TCCR2B |= (1<<WGM22) | (1<< CS22) | (1<< CS21) | (1<< CS20);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR2A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR2B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
	
	
}


void servoOpen(void) {
	
	OCR2B = 16;
}