/*
 * EmbeddedFinalProject.c
 *
 * Created: 4/18/2018 8:07:23 PM
 * Author : Jacob / Josh
 */ 

#include <avr/io.h>
#include "util/delay.h"
#include "nokia5110.h"



int main(void)
{
   
    while (1) 
    {
		
	//to find the specifics on how they functions work see nokia5110.c	
	
	//must be called once to initialize the display
	nokia_lcd_init();
	//clear the screen
	nokia_lcd_clear();
	//the second param is the scale or size of the message
	nokia_lcd_write_string( "Its Working!",1);
	// X-horizontal position, Y - vertical position
	nokia_lcd_set_cursor(0, 10);
	nokia_lcd_write_string("Nice!", 3);
	//actually sends the written strings to the display
	nokia_lcd_render();
	 
	 for (;;) {
		 _delay_ms(1000);
	 } 
	 
	 
    }//end while
}//end main

