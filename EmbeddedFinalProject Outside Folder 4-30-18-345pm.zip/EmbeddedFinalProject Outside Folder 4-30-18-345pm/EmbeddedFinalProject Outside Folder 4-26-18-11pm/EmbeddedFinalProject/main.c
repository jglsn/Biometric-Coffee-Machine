/*
 * EmbeddedFinalProject.c
 *
 * Created: 4/18/2018 8:07:23 PM
 * Author : Jacob / Josh
 */ 
#include <stdio.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>

#include "util/delay.h"
#include "nokia5110.h"
#define BAUD_RATE 9600        //Baud Rate
#define F_CPU 8000000L        //Clock Frequency
#define RX_BUFFER_SIZE 64

unsigned char rx_buffer[RX_BUFFER_SIZE];//variables and functions for rx buffer
volatile unsigned char rx_buffer_head;
volatile unsigned char rx_buffer_tail;

/*USART functions*/
char uart_buffer_empty(void);
void usart_init(void);
void usart_putData(const char data);
char usart_getData(void);

/*Motor functions*/
void pwmInit0(void);
void servoOpen0(void);
void pwmInit2(void);
void servoOpen2(void);

//LCD Functions
void printMenu();
void enrollUserPrint();
//*char removeUser();
void settingsMenuPrint();

//Pin interrupt
volatile char previousPins=0;
volatile char pins=0;
volatile char rpgDir = 0;
volatile int counter=1;	
volatile int prevCounter=0;
volatile int arrowPosition = 10;
volatile char prevLow= 0x00;
volatile char prevHigh= 0x00;
volatile int menuChoice=0;
volatile int menuChoice2=0;
volatile int level=1;
int main(void)
{
	
	//********************* RPG MENU SCROLL***************************	
	//DDRB = 0b00000110	//PB1, PB2 inputs from the RPG
	//DDRD = 0b00000110;
	//PORTD = 0b00000110;	//enable pull up resistors 
	
	/*INTERRUPT*/
	
	PCICR |= (1<<PCIE1)|(1<<PCIE0);	//sets PCIE1 Flag turns on PCINT[14:8]
	PCMSK1 |= (1<<PCINT13)|(1<<PCINT12);	//enables PCINTS 12 and 13
	PCMSK0|= (1<<PCINT0);
	
	DDRC |= 0x00;
	//PORTC|=0b00110000;
	sei();

	/*lcd*/
	DDRB = 0b00111110;
	nokia_lcd_init();
	printMenu(arrowPosition);
	
	while(1)
	{	
	prevCounter=counter;
	if(counter==prevCounter){	
		
	}else{
		//nokia_lcd_set_cursor(0, arrowPosition);
		//nokia_lcd_write_string("  ", 1);
		cli();
		arrowPosition = 10*counter;
		printMenu(arrowPosition);	
		_delay_ms(1000);
		sei();
	}
	/*******************************Pushbutton use************************************/
	


	if(menuChoice == 30){	//settings menu
		settingsMenuPrint();		//rolling rpg at all inside settings menu takes you back to main menu
		menuChoice = 0;	//reset the 1st level menu choice so it doesnt jump right back into 2nd level
		level=2;
	}
	else if (menuChoice == 10){ // Enroll User
		enrollUserPrint();
		
	}
	
	if(menuChoice2 == 30){	//back to main
			menuChoice = 0;
			printMenu(arrowPosition);
			level=1;
			menuChoice2 = 0;
	}
		//print
		
		
	}

	
//ACTION PLAN 4/29/18
//the back functionality from within the 2nd level of our menus is not working. The arrow no longer moves with the rpg turn in level 2.
	
	
	
	
	
		
		
}
		

	//*****************************************************************
	
		/*
		// Motor Code
		DDRD = 0b00101000 ; // set PD3 and PD5 as an output for the servo
		pwmInit0();
		pwmInit2();
		servoOpen0();
	*/
/*
	//********************           LCD          *************************************
	nokia_lcd_init();
	DDRB = 0b00111110;
	#define volatile int arrowPosition = 10;	//start the arrow on the 2nd line of the LCD
	int menuChoice = 0, menuChoice2 = 0;
	 

	printMenu(arrowPosition);
	
	//user will change arrow location by ISR
	//enable function for user to select choice (arrow location) by pushing button

	//enroll user
	if(menuChoice = 10){	
		enrollUserPrint();
		//function to enroll user
	}
	
	
	
	//Remove User
	else if (menuChoice = 20){ 
		removeUserPrint();
		//function to remove user	
	}
	
	
	
	
	// Settings
	else if (menuChoice = 30){ 
		settingsMenuPrint();
		if (menuChoice2 = 10){	//set coffee
			//function to setCoffee
		}
		else if (menuChoice2 = 20){	//set creamer
			//function to setCreamer
		}
		else{	//empty lines -- invalid input
			nokia_lcd_clear();
			nokia_lcd_set_cursor(0,0);
			nokia_lcd_write_string("Please Enter", 1);
			nokia_lcd_set_cursor(0,0);
			nokia_lcd_write_string("Valid Input", 1);
			nokia_lcd_render();
		}
	}
	
	
	// Auto Pour
	else if (menuChoice = 40){
		autoPourPrint();
		//function to read user swipe
		
		//functions to operate servos and pour
	}
	else{	// i don't think this condition can ever be met with our system the arrow will always be 10,20,30,40
		nokia_lcd_clear();
		nokia_lcd_set_cursor(0,0);
		nokia_lcd_write_string("Please Enter", 1);
		nokia_lcd_set_cursor(0,0);
		nokia_lcd_write_string("Valid Input", 1);
		nokia_lcd_render();
	}
	
	
	
	
	
	
}//end main


*/




//%%%%%%%%%%%%%%%%%&&&&%%%%%% FUNCTION DEFINITIONS &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

//********************       Servo PWM      *************************************
void pwmInit0(void){
	
	
	TCCR0A |= (1<<WGM01) | (1<<WGM00) | (1<<COM0B1);	// configuring for fast pwm
	
	TCCR0B |= (1<<WGM02) | (1<< CS02) | (1<< CS00);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR0A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR0B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
}

void servoOpen0(void) {
	
	OCR0B = 16;
}

void pwmInit2(void){
	
	
	TCCR2A |= (1<<WGM21) | (1<<WGM20) | (1<<COM2B1);	// configuring for fast pwm
	
	TCCR2B |= (1<<WGM22) | (1<< CS22) | (1<< CS21) | (1<< CS20);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR2A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR2B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
	
	
}

void servoOpen2(void) {
	
	OCR2B = 16;
}



//************************     USART HAPPY FUN TIME     *************************

/*Interrupt service routine for buffer*/
ISR(USART_RX_vect)
{
	// UART receive interrupt handler.
   // To do: check and warn if buffer overflows.
	
	char c = UDR0;
	rx_buffer[rx_buffer_head] = c;
	if (rx_buffer_head == RX_BUFFER_SIZE - 1)
	rx_buffer_head = 0;
	else
	rx_buffer_head++;
}

/*USART Initialization*/
void usart_init(void)
{	unsigned short s;//variable for Baud Rate

	s = (double)F_CPU / (BAUD_RATE*16.0) - 1.0;//Baud Rate Calculation
	UBRR0H = (s & 0xFF00);//set high byte
	UBRR0L = (s & 0x00FF);//set low byte

	UCSR0B = (1<<RXCIE0)|(1<<RXEN0)|(1<<TXEN0);//enable hardware interrupt on rx, enable tx,rx

	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);//8N1 communication
	
	DDRD |= (1<< 1);         // PD0 is output (TX)
	DDRD &= ~(1<< 0);        // PD1 is input (Rx)
	
	rx_buffer_head = 0; //empty buffer
	rx_buffer_tail = 0;
}

/*return typed char to USART*/
void usart_putData(const char data){
	// Send "c" via the USART.  Uses poling
	// (and it blocks). Wait for UDRE0 to become
	// set (=1), which indicates the UDR0 is empty
	// and can accept the next character.

	while (!(UCSR0A & (1<<UDRE0)))
	;
	UDR0 = data;
}

/*Get character from receive buffer*/
char usart_getData(void)
{	// Get char from the receiver buffer.  This
	// function blocks until a character arrives.
	
	unsigned char  data;
	
	// Wait for a character in the buffer.

	while (rx_buffer_tail == rx_buffer_head)
	;
	
	data = rx_buffer[rx_buffer_tail];
	if (rx_buffer_tail == RX_BUFFER_SIZE-1)
	rx_buffer_tail = 0;
	else
	rx_buffer_tail++;
	return data;
}

/*Character Buffer*/
 char uart_buffer_empty(void)
{
	// Returns TRUE if receive buffer is empty.
	return (rx_buffer_tail == rx_buffer_head);
}


//*************************************LCD FUNCTIONS********************************************
void printMenu(volatile int arrowPosition){
		cli();	//we dont want another turn of the rpg to trigger a nested ISR inside of this
		//initial screen print
		nokia_lcd_clear();
		nokia_lcd_set_cursor(0 , 0);
		nokia_lcd_write_string( "  MAIN MENU",1);
		nokia_lcd_set_cursor(0 , arrowPosition);
		nokia_lcd_write_string( "->",1);
		nokia_lcd_set_cursor(15, 10);
		nokia_lcd_write_string( "Enroll User",1);
		nokia_lcd_set_cursor(15, 20);
		nokia_lcd_write_string("Remove User", 1);
		nokia_lcd_set_cursor(15, 30);
		nokia_lcd_write_string( "Settings",1);
		nokia_lcd_set_cursor(15, 40);
		nokia_lcd_write_string( "Auto Pour",1);
		nokia_lcd_render();
		sei();
}


//this function should be our interrupt service routine!! (you cant call functions from ISRS
//so we will just copy this code into the ISR)
/*
int moveArrow(int arrowPosition){
	
	//need to put code here to use the proper ISR vectors
	//we will need to use 2 pin change interrupts in our case
	
		cli();	//we don't want another turn of the RPG to trigger a nested ISR inside of this

		if (){ //CW rotation (arrow down)
			if(arrowPosition < 40){
				arrowPosition = (arrowPosition + 10);	//moves arrow down 1 line
			}
			else{	//arrow is at bottom line of LCD, must take back to top
				arrowPosition = 10;
			}
		} 
		
		
		else if (){ //CCW rotation (arrow up)
			if(arrowPosition > 10){
				arrowPosition = (arrowPosition - 10);	//move the arrow up 1 line
			}
			else{	//arrow is as top line of LCD, must take back to bottom
				arrowPosition = 40;
			}
		}
		
		
		else{ //no rotation
		}
		
		return arrowPosition;	//sends back the updated arrow position for printing purposes	
}*/



void enrollUserPrint(){
	nokia_lcd_clear();
	nokia_lcd_set_cursor(0,0);
	nokia_lcd_write_string( " ENROLL USER",1);
	nokia_lcd_set_cursor(0,10);
	nokia_lcd_write_string( "Please Swipe",1);
	nokia_lcd_set_cursor(0,20);
	nokia_lcd_write_string("Card...",1);
	nokia_lcd_render();
}


void removeUserPrint(){
	nokia_lcd_clear();
	nokia_lcd_set_cursor(0,0);
	nokia_lcd_write_string( " REMOVE USER",1);
	nokia_lcd_set_cursor(0,10);
	nokia_lcd_write_string( "Please Swipe",1);
	nokia_lcd_set_cursor(0,20);
	nokia_lcd_write_string("Card...",1);
	nokia_lcd_render();
}


void settingsMenuPrint(){
	
	//before we can do this we need to have the user identify themselves too
		nokia_lcd_clear();
		nokia_lcd_set_cursor(0 , 0);
		nokia_lcd_write_string( "   SETTINGS",1);
		nokia_lcd_set_cursor(0 , 10);
		nokia_lcd_write_string( "->",1);
		nokia_lcd_set_cursor(15,10);
		nokia_lcd_write_string( "Set Coffee",1);
		nokia_lcd_set_cursor(15,20);
		nokia_lcd_write_string( "Set Creamer",1);
		nokia_lcd_set_cursor(15,30);
		nokia_lcd_write_string( "Back",1);
		nokia_lcd_render();
}


void autoPourPrint(){
	nokia_lcd_clear();
	nokia_lcd_set_cursor(0,0);
	nokia_lcd_write_string( "  AUTO POUR",1);
	nokia_lcd_set_cursor(0,10);
	nokia_lcd_write_string( "Swipe Card",1);
	nokia_lcd_set_cursor(0,20);
	nokia_lcd_write_string( "to Dispense...",1);
	nokia_lcd_render();
	//maybe call a fxn here to alert the strip reader to wait for a swipe?
}





//******************************RPG FUNCTIONS************************************
ISR(PCINT1_vect){
cli();
previousPins=pins;
pins= (PINC & 0x30);
prevLow= (pins & 0x10);
prevHigh= (pins & 0x20);
prevLow=prevLow*2;
prevHigh=prevHigh/2;
prevLow=prevLow|prevHigh;
rpgDir=previousPins^prevLow;	//XOR
	
if(rpgDir==0x10){
	counter=counter+1;
	if(counter>4){
		counter=1; //cw
		}
		
	}
	else if(rpgDir==0x20){
		counter=counter-1;
		if(counter<1){
			counter=4;
		}
			
	}
	sei();
	}

ISR(PCINT0_vect){
	cli();
	if(level == 1){
	menuChoice = arrowPosition;
	}
	else if(level == 2){
		menuChoice2 = arrowPosition;
	}
	
	sei();
}