/*
 * EmbeddedFinalProject.c
 *
 * Created: 4/18/2018 8:07:23 PM
 * Author : Jacob / Josh
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include "util/delay.h"
#include "nokia5110.h"
#define BAUD_RATE 9600        //Baud Rate
#define F_CPU 8000000L        //Clock Frequency
#define RX_BUFFER_SIZE 64

unsigned char rx_buffer[RX_BUFFER_SIZE];//variables and functions for rx buffer
volatile unsigned char rx_buffer_head;
volatile unsigned char rx_buffer_tail;

/*USART functions*/
unsigned char uart_buffer_empty(void);
void usart_init(void);
void usart_putc(const char c);
unsigned char usart_getc(void);

/*Motor functions*/
void pwmInit0(void);
void servoOpen0(void);
void pwmInit2(void);
void servoOpen2(void);

int main(void)
{
	sei();//enable global interrupts
	usart_init();//configure USART
	
	/* ACTION PLAN
	
	change the get_c and put_c commands from char to work with commands
	
    define all of the necessary FPS commands (they are in the FPS_GT511C3.h file)
	
	use the commands to attempt to make a blinky program on the FPS led
	
	*/
	
	
	
	
	
	/*
	// Motor Code
	DDRD = 0b00101000 ; // set PD3 as an output for the servo
	pwmInit0();
	pwmInit2();
	servoOpen0();
*/
/*
//********************           LCD          *************************************
	nokia_lcd_init();
	//clear the screen
	nokia_lcd_clear();
	//the second param is the scale or size of the message
	nokia_lcd_write_string( "Its Working!",1);
	//X-horizontal position, Y - vertical position
	nokia_lcd_set_cursor(0, 10);
    nokia_lcd_write_string("Shane!", 2);
	//actually sends the written strings to the display
	nokia_lcd_render();
	  for (;;) {
		 _delay_ms(1000);
	 } 
	*/ 
}//end main

//********************       Servo PWM      *************************************
void pwmInit0(void){
	
	
	TCCR0A |= (1<<WGM01) | (1<<WGM00) | (1<<COM0B1);	// configuring for fast pwm
	
	TCCR0B |= (1<<WGM02) | (1<< CS02) | (1<< CS00);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR0A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR0B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
	
	
}

void servoOpen0(void) {
	
	OCR0B = 16;
}

void pwmInit2(void){
	
	
	TCCR2A |= (1<<WGM21) | (1<<WGM20) | (1<<COM2B1);	// configuring for fast pwm
	
	TCCR2B |= (1<<WGM22) | (1<< CS22) | (1<< CS21) | (1<< CS20);		// configuring for fast pwm ,,setting the 1024 prescaler
	
	OCR2A = 95;		// T=20ms, 50Hz freq
	
	//this value will be adjusted depending on user input
	OCR2B = 8;		//runs for 8 cycles at 1.28E-4s/Cycle = .78 ~ 8 to take 1ms
	
	
	
}

void servoOpen2(void) {
	
	OCR2B = 16;
}



//************************     USART HAPPY FUN TIME     *************************

/*Interrupt service routine for buffer*/
ISR(USART_RX_vect)
{
	// UART receive interrupt handler.
	// To do: check and warn if buffer overflows.
	
	char c = UDR0;
	rx_buffer[rx_buffer_head] = c;
	if (rx_buffer_head == RX_BUFFER_SIZE - 1)
	rx_buffer_head = 0;
	else
	rx_buffer_head++;
}

/*Usart Initialization*/
void usart_init(void)
{
	// Configures the USART for serial 8N1 with
	// the Baud rate controlled by a #define.

	unsigned short s;
	
	// Set Baud rate, controlled with #define above.
	
	s = (double)F_CPU / (BAUD_RATE*16.0) - 1.0;
	UBRR0H = (s & 0xFF00);
	UBRR0L = (s & 0x00FF);

	// Receive complete interrupt enable: RXCIE0
	// Receiver & Transmitter enable: RXEN0,TXEN0

	UCSR0B = (1<<RXCIE0)|(1<<RXEN0)|(1<<TXEN0);

	// Along with UCSZ02 bit in UCSR0B, set 8 bits
	
	UCSR0C = (1<<UCSZ01)|(1<<UCSZ00);
	
	DDRD |= (1<< 1);         // PD0 is output (TX)
	DDRD &= ~(1<< 0);        // PD1 is input (Rx)
	
	// Empty buffers
	rx_buffer_head = 0;
	rx_buffer_tail = 0;
}

/*return typed char to USART*/
void usart_putc(const char c){
	// Send "c" via the USART.  Uses poling
	// (and it blocks). Wait for UDRE0 to become
	// set (=1), which indicates the UDR0 is empty
	// and can accept the next character.

	while (!(UCSR0A & (1<<UDRE0)))
	;
	UDR0 = c;
}

/*Get character from receive buffer*/
unsigned char usart_getc(void)
{	// Get char from the receiver buffer.  This
	// function blocks until a character arrives.
	
	unsigned char c;
	
	// Wait for a character in the buffer.

	while (rx_buffer_tail == rx_buffer_head)
	;
	
	c = rx_buffer[rx_buffer_tail];
	if (rx_buffer_tail == RX_BUFFER_SIZE-1)
	rx_buffer_tail = 0;
	else
	rx_buffer_tail++;
	return c;
}


/*Character Buffer*/
unsigned char uart_buffer_empty(void)
{
	// Returns TRUE if receive buffer is empty.
	return (rx_buffer_tail == rx_buffer_head);
}
